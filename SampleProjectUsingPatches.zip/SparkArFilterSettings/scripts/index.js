//
// SparkAR Modules
//
const Patches = require('Patches');
const Tex = require('Textures');

//
// Local Dependencies
//
import { FilterSettings } from './FilterSettings';

//
// Setup filter settings
//
FilterSettings.configure({
	contrast: {
		icon: Tex.findFirst('iconContrast')
	},
	lightness: {
		icon: Tex.findFirst('iconBrightness'),
		default: 0.5,
	},
	saturation: {
		icon: Tex.findFirst('iconSaturation'),
	}
}, onUpdate);


// Function that adjust colors
function onUpdate(evt) {
	Patches.inputs.setScalar('contrast', FilterSettings.contrast);
	Patches.inputs.setScalar('lightness', FilterSettings.lightness);
	Patches.inputs.setScalar('saturation', FilterSettings.saturation);
}

// Trigger once on init
onUpdate();
