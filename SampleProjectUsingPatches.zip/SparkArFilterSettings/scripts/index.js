//
// SparkAR Modules
//
const Patches = require('Patches');
const Tex = require('Textures');

//
// Local Dependencies
//
import { FilterSettings } from './FilterSettings';

//
// Setup filter settings
//
FilterSettings.configure({
	contrast: {
		icon: Tex.get('iconContrast')
	},
	lightness: {
		icon: Tex.get('iconBrightness'),
		default: 0.5,
	},
	saturation: {
		icon: Tex.get('iconSaturation'),
	}
}, onUpdate);


// Function that adjust colors
function onUpdate(evt) {
	Patches.setScalarValue('contrast', FilterSettings.contrast);
	Patches.setScalarValue('lightness', FilterSettings.lightness);
	Patches.setScalarValue('saturation', FilterSettings.saturation);
}

// Trigger once on init
onUpdate();
